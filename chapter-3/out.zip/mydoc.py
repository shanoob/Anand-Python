print pydoc os
